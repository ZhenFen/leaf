#include <CryptoTypes.h>
#include <list>
#include <stdio.h>
#include <cstring>
#include <iostream>

#include <iterator>
#include <mutex>
#include <set>
#include <atomic>
#include <unordered_map>
#include "Common/StringTools.h"

#include "Common/Base58.h"
//#define HASH_SIZE 32

#define MAX_TREE_DEPTH 14
#define STEPS 20

#ifndef HASHOPS
#define HASHOPS
extern "C"{
	#include "crypto/hash-ops.h"
}
#endif

#include "HashTree.h"

using namespace Crypto;
using namespace timehash;

namespace  timehash{

void hash2hash(Hash& hash1, Hash& hash2, Hash& result){
	uint8_t hashes[2*HASH_SIZE];
	
	memcpy(hashes,hash1.data,HASH_SIZE);
	memcpy(hashes+HASH_SIZE,hash2.data,HASH_SIZE);
	cn_fast_hash(hashes,2*HASH_SIZE, (char*)result.data);
};
	

	bool HashTree::newparent(entry* newentry, int height){
		Hash parentHash;
		
		if(newentry->sibling==0)
			return false;
			
		newentry->sibling->sibling=newentry; //reverse connect to siblings
		hash2hash(newentry->hash, newentry->sibling->hash, parentHash);
		roots[height]=0;
		
		if(!insertentry(parentHash,newentry->parent,newentry,height+1))
			return false;
				
		if(newentry->sibling==0)
			return false;
			
		newentry->sibling->parent=newentry->parent;
		
		return true;
	};
		
	bool HashTree::insertentry(Hash& hash, entry*& newentry, entry* child1, int height){
		try{ newentry=new entry; } 
			catch(std::bad_alloc&){	return false; }
		
		newentry->hash=hash;
		newentry->child1=child1;
		newentry->sibling=0;
		
		if(roots[height]!=0){
			newentry->sibling=roots[height]; //connect to sibling
			
			if(!newparent(newentry, height))
				return false;
		}
		else roots[height]=newentry;
		
		return true;
	};
	
	bool HashTree::connectalltoroot(){
		entry* first;
		entry* second;
		mut.lock();
		
		first=0;
		for(int i=0;i<20;i++){
			if(roots[i]!=0){
				if(first==0){
					first=roots[i];
				}
				else {
					second=roots[i];
					second->sibling=first;
					if(!newparent(second,i)){
						mut.unlock();
						return false;
					}
					first=0;
				};
			};	
		};
		roothash=first;
		connected=true;
		
		mut.unlock();
		
		return true;
	};
	
	void HashTree::clearentry(entry* e){
		if(e->child1!=0){
			clearentry(e->child1);
			clearentry(e->child1->sibling);
		};
		
		delete e;
	}
	
	void HashTree::init(){
		mut.lock();
		roothash=0;
		connected=false;
		for(int i=0;i<20;i++)
			roots[i]=0;
		mut.unlock();
	};
	
	void HashTree::clear(){
		if(!connected)
			connectalltoroot();
			
		mut.lock();
		if(roothash!=0)
			clearentry(roothash);
		mut.unlock();
		
		init();
	};
	
		
	std::string HashTree::pathtoroot(void* initpointer){
		entry* current = (entry*)initpointer;
		
		std::string path("");
		if(current==0)
			return path;
			
		std::string str1, str2;
		
		unsigned char counter=0;
		str1 = Common::asString(current->hash.data,HASH_SIZE);
		
		while(current->sibling!=0){
			str2 = Common::asString(current->sibling->hash.data,HASH_SIZE);
			if(current->parent==0)
				return "ERROR";
			if(current->parent->child1==current)
				path=path+str1+str2;
			else if (current->parent->child1==current->sibling)
				path=path+str2+str1;
			else
				return path;
			current=current->parent;
			str1 = Common::asString(current->hash.data,HASH_SIZE);
			counter++;
		}
		path+=str1;
		path.push_back(counter);
		
		return path;
	};
	
	bool HashTree::insert(Hash& hash, void*& pointer){
		entry* firstentry;
		mut.lock();
		
		if(connected){
			mut.unlock();
			return false;
		}	
		bool r=insertentry(hash, firstentry, 0, 0);
		mut.unlock();
		pointer=(void*)firstentry;
		//if(r==false)std::cout<<"\n\nFFFFUUUUUCK\n\n\n";
		return r;
	};
	
	bool HashTree::insert(Hash& hash){
		entry* firstentry;
		mut.lock();
		
		if(connected){
			mut.unlock();
			return false;
		}	
		bool r=insertentry(hash, firstentry, 0, 0);
		mut.unlock();
		return r;
	};
	
	void HashTree::addpath(std::string& allpaths, void* initpointer){
		unsigned char paths=0;
		if(allpaths.size()>0){
			paths=allpaths.back();
			allpaths.pop_back();
		}
		mut.lock();
		std::string newpath = pathtoroot(initpointer);
		mut.unlock();
		if(newpath.size()>3*HASH_SIZE){
			paths++;
			allpaths+=newpath;
		}
		allpaths.push_back(paths);
	}; 

	 std::string HashTree::lonelypath(void* initpointer){
		mut.lock();
		std::string newpath = pathtoroot(initpointer);
		mut.unlock();
		
		return newpath;
	}; 

	Hash HashTree::getroot(){
		mut.lock();
		Hash ret = roothash->hash;
		mut.unlock();
		return ret;
	};


bool verifypath(std::string& str,std::string& verified, std::string& endhash, std::string& prehash1, std::string& prehash2){
	unsigned char buffer1[2*HASH_SIZE];
	unsigned char buffer2[2*HASH_SIZE];
	unsigned char* prehashes=buffer1;
	unsigned char* metahashes=buffer2;

	std::string print;

	Hash result;
	if(str.size()<3*HASH_SIZE)
		return false;
	unsigned char loops=str.back();
	
	if(loops>MAX_TREE_DEPTH)
		if(loops<1)
			return false;
	unsigned int size=((unsigned int)loops*2+1)*HASH_SIZE+1;
	
	if(str.size()<size)
		return false;
	verified.resize(verified.size()+size);	
	std::copy(str.end()-size,str.end(),verified.end()-size);
	
	str.pop_back();
	endhash.resize(HASH_SIZE);
	std::copy(str.end()-(HASH_SIZE),str.end(),metahashes);
	
	std::copy(str.end()-(HASH_SIZE),str.end(),endhash.begin());
	
	str.resize(str.size()-(HASH_SIZE));
	
	for(unsigned char i=loops;i>0;i--){
		std::copy(str.end()-(2*HASH_SIZE),str.end(),prehashes);
		
		str.resize(str.size()-(2*HASH_SIZE));
		cn_fast_hash(prehashes,2*HASH_SIZE, (char*)result.data);
		
		if(!std::equal(metahashes,metahashes+HASH_SIZE,result.data))
			if(!std::equal(metahashes+HASH_SIZE,metahashes+(2*HASH_SIZE),result.data))
				return false;
		
		std::swap(prehashes,metahashes);
	}
	prehash1.resize(HASH_SIZE);
	prehash2.resize(HASH_SIZE);
	std::copy(metahashes,metahashes+HASH_SIZE,prehash1.begin());
	std::copy(metahashes+HASH_SIZE,metahashes+(2*HASH_SIZE),prehash2.begin());

	return true;
};

bool verifypaths(std::string& str, Timehashes& mytimehashes, Timehashlists& timehashlists){
	std::string verified;
	std::string endhash;
	std::string prehash1;
	std::string prehash2;
	
	bool success;
	
	if(str.size()<3*HASH_SIZE)
		return false;
	
	unsigned char loops=str.back();
	
	str.pop_back();
	if(loops>STEPS)
		return false;
		
	for(unsigned char i=0;i<loops;i++){
		verified.clear();
		if(!verifypath(str,verified,endhash, prehash1, prehash2))
			return false;
		
		if(!mytimehashes.find(prehash1))
			if(!mytimehashes.find(prehash2))
				continue;
		
		success=true;
		timehashlists.insert(endhash,verified);
	}
	
	return success;
}


bool verifypathchain(Hash& TimeHash, std::string& str, Timehashes& mytimehashes, Timehashlists& timehashlists){
	std::string verified;
	std::string endhash;
	std::string prehash1;
	std::string prehash2;
	std::string phash1;//resize
	std::string phash2;
	std::string headhash;
	
	std::string timehashstr = Common::asString(TimeHash.data,HASH_SIZE);
	unsigned char loops=0;
	
	if(str.size()>3*HASH_SIZE){
		loops=str.back();
		str.pop_back();
		
		std::string temp=str;
	
		if(loops>STEPS)
			return false;
	
		for(int i=0;i<loops;i++){
			phash1=prehash1;//todo implement with swap
			phash2=prehash2;
			if(!verifypath(temp,verified, endhash, prehash1, prehash2))
				return false;
			if(i==0)
				headhash=endhash;
			if(!phash1.empty())
				if(phash1!=endhash)
					if(phash2!=endhash)
						return false;
		}	
	
		if(headhash!=timehashstr)
			return false;
	} else {
		prehash1=timehashstr;
	}
	
	if(mytimehashes.find(prehash1))
		return true;
	if(mytimehashes.find(prehash2))
		return true;
		
	std::string found;	
	if(!timehashlists.find(prehash1, found))
		if(!timehashlists.find(prehash2, found))
			return false;
	
	str=found+str;
	str.push_back(loops+1);
	
	return true;
}

}//namespace timehash
