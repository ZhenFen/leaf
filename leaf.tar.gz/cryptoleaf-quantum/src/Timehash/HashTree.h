//delete some below
#include <CryptoTypes.h>
#include <list>
#include <stdio.h>
#include <cstring>
#include <iostream>
#include "crypto/hash-ops.h"
#include <iterator>
#include <mutex>
#include <set>
#include <unordered_map>
#include "Common/StringTools.h"
#include "timehashtools.h"
#include <atomic>

#ifndef TIMEHASHTREE
#define TIMEHASHTREE


//#define HASH_SIZE 32

#define MAX_TREE_DEPTH 14
#define STEPS 20

/*
#define NEXT_FAKE_HASH result.data[cd]=cv;  cv++;if(cd>31)cd=0; if(cv=='W')cv='A',cd++;
#define TEST_FAKE_HASH std::fill(std::begin(result.data),std::end(result.data),'A'); NEXT_FAKE_HASH
*/

/*
struct Hash {
  unsigned char data[32];
};
*/


using namespace Crypto;
using namespace timehash;

namespace  timehash{

void hash2hash(Hash& hash1, Hash& hash2, Hash& result);
	
class HashTree{
	public:
	struct entry{
		Hash hash;
		entry* parent;
		entry* sibling;
		entry* child1;
	};
  public:
	bool connectalltoroot();
	void init();
	void clear();
	
	bool insert(Hash& hash, void*& pointer);
	bool insert(Hash& hash);
	 
	void addpath(std::string& allpaths, void* initpointer); 
	std::string lonelypath(void* initpointer);
	Hash getroot();
			
  private:
	entry* roots[20];
	entry* roothash;
	
	std::mutex mut;
	std::atomic<bool> connected;
	
  	bool newparent(entry* newentry, int height);
	bool insertentry(Hash& hash, entry*& newentry, entry* child1, int height);
	void clearentry(entry* e);
	
	std::string pathtoroot(void* initpointer);
};


bool verifypath(std::string& str,std::string& verified, std::string& endhash, std::string& prehash1, std::string& prehash2);

bool verifypaths(std::string& str, Timehashes& mytimehashes, Timehashlists& timehashlists);

bool verifypathchain(Hash& TimeHash, std::string& str, Timehashes& mytimehashes, Timehashlists& timehashlists);

}//namespace timehash
#endif
