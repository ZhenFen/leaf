#include <CryptoNote.h>
#include <CryptoTypes.h>

#include <cstdio>
#include <chrono> 
#include <vector>
#include <unordered_map>
#include <set>

#ifndef TIMEHASH_TOOLS
#define TIMEHASH_TOOLS

using namespace Crypto;
using namespace Common;
using namespace CryptoNote;

namespace timehash{

	class Timehashes{
	  public:	
		std::mutex mut;
		std::set<std::string> mytimehashes;;
		bool find(std::string& str);
		void clear();
		void insert(Hash th);
	};
	
	class Timehashlists{
	  public:	
		std::mutex mut;
		std::unordered_map<std::string, std::string> timehashlists;
		bool find(std::string& str, std::string& result);
		void clear();
		void insert(std::string& first, std::string& second);
	};
	
	class Tickets{
	  public:		
		std::mutex mut;
		std::list<Hash> tickets;
		std::list<Hash> latetickets;
		std::list<Hash> validprevioustickets;
		void restart();
		bool ready();
		void insert(Hash& title);
		void insertlate(Hash& title);
		void validate(Hash& title);
		void invalidate(Hash& blockhash);
		bool haveticket(Hash& title, std::list<Hash>& tickets);
		bool havecurrentticket(Hash& title);
		bool havelateticket(Hash& title);
		bool havepreviousticket(Hash& title);
		bool haveticket(Hash& title);
	};
	
	BinaryArray StringtoBinaryArray(std::string& str);
	BinaryArray HashtoBinaryArray(Hash hash);
	bool BinaryArraytoString(BinaryArray& binaryArray, std::string& str);
	bool BinaryArraytoHash(BinaryArray& binaryArray, Hash& hash);
}	
#endif
