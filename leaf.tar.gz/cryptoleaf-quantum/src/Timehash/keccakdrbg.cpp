#include <CryptoTypes.h>

#include <stdio.h>
#include <string.h>
#include <iostream>
extern "C"{
	#include "crypto/hash-ops.h"
}
#include "keccakdrbg.h"
 
using namespace Crypto;

namespace timehash{
	void KeccakDrbg::seed(void* cn_data, char* s, size_t size){
		cn_ctx_data = cn_data;
		cn_slow_hash_f(cn_data, s, size, reinterpret_cast<void *>(&C));
		
		cn_fast_hash(s, size, V);
		
		memcpy(V+HASH_SIZE, C.data, HASH_SIZE);
		
		//backup
		memcpy(Vback, V, 2*HASH_SIZE);
		Cback = C;		
	}
	
	Hash KeccakDrbg::rand(){
		Hash rnd;
		cn_fast_hash(V, 2*HASH_SIZE, (char*)rnd.data);
		memcpy(V, rnd.data, HASH_SIZE);
		return rnd;
	}
	
	void KeccakDrbg::reseed(char* s, size_t size){
		cn_fast_hash(s, size, V+HASH_SIZE);
		cn_fast_hash(V, 2*HASH_SIZE, (char*)C.data);
		
		memcpy(V, C.data, HASH_SIZE);
		cn_slow_hash_f(cn_ctx_data, V, size, reinterpret_cast<void *>(&C));
		
		memcpy(V+HASH_SIZE, C.data, HASH_SIZE);
	}
	
	void KeccakDrbg::restart(){
		//restore
		memcpy(V, Vback, 2*HASH_SIZE);
		C=Cback;
	}
}
