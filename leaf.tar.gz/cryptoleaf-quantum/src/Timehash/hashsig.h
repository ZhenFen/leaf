#include <CryptoTypes.h>
#include <list>
#include <map>
#include <stdio.h>
#include "HashTree.h"
#include "keccakdrbg.h"
#include <iostream>
//#include "CryptoNoteCore/Difficulty.h"

#define CONFIRMATION_DISTANCE 6
#define POB_BLOCKS 2

#ifndef HASH_SIG
#define HASH_SIG

using namespace Crypto;



namespace timehash{
	struct comp{
			bool operator() (const Hash& lhs, const Hash& rhs) const{
				if((uint64_t)(*(lhs.data))!=(uint64_t)(*(rhs.data))) 
					return (uint64_t)(*(lhs.data))<(uint64_t)(*(rhs.data));
				if((uint64_t)(*(lhs.data+8))!=(uint64_t)(*(rhs.data+8))) 
					return (uint64_t)(*(lhs.data+8))<(uint64_t)(*(rhs.data+8));	
				if((uint64_t)(*(lhs.data+16))!=(uint64_t)(*(rhs.data+16))) 
					return (uint64_t)(*(lhs.data+16))<(uint64_t)(*(rhs.data+16));	
				if((uint64_t)(*(lhs.data+24))!=(uint64_t)(*(rhs.data+24))) 
					return (uint64_t)(*(lhs.data+24))<(uint64_t)(*(rhs.data+24));			
				return false;
			}
		};
	
	

////////////////////////////////////////////////////////////////////////////	
	
	struct keypair{
		Hash priv[64];
		Hash pub;
	};
	
		
	struct bundle{
		Hash root;
		Hash children[8];
		uint8_t used = 0;
		int height;
	};
	
	
	class HashSig{
		std::list<keypair> keys;
		KeccakDrbg drbg;
		HashTree tree;
	  
	  public:	
		void init(void* cn_data, char* seed, size_t size);
		void add();
		void add(Hash& pub);
		void reseed(Hash& hash);
		bundle add8();
		bool sign(Hash& message, Hash& pub, Hash sig[64]);
		bool sign(Hash& message, Hash& pub, Hash sig[64], int numberofnextsigs, std::list<Hash>& next);
		bool search(Hash& hash, std::list<keypair>::iterator& it);
		bool remove(Hash& hash);
		void clear();
	};
	
/////////////////////////////////////////////////////////////////////////////	

	struct rigtree {
		HashSig Sig;
		std::list<bundle> sigs;
		std::list<bundle>::iterator lastSig;
		std::list<bundle>::iterator initSig;
		HashTree* tree;
		std::map<Hash, void*, comp> keys;
		int height;
	};
	
	class VirtualRig {
			
		KeccakDrbg drbg;
		HashTree ht;
		std::map<Hash, void*, comp> keys;
		void* cnd;
		
	  public:
	    std::list<rigtree*> trees;
	    //HashSig Sig;
		std::list<rigtree*>::iterator last;
		
		bool initialized;
		std::mutex mut;
		
		void init(void* cn_data, std::string str);
		void init(void* cn_data, char* seed, size_t size);
		
		Hash add();
		Hash add(void* cndata);
		void add(Hash& pub);
		void add(Hash& pub, void* cndata);
		bool closeto(Hash& hash, std::string& path, uint64_t& diff);
		bool searchRoot(const Hash& hash, std::list<rigtree*>::iterator& it);
		bool sigsearch(Hash& hash, std::list<bundle>::iterator& it, std::list<rigtree*>::iterator& r);
		void nextsig(Block& block, rigtree* r);
		bool constructblock(Block& block, Hash target, uint64_t& diff, std::string& path, std::list<rigtree*>::iterator& r);
		bool finishblock(Block& block, Hash& blockhash, std::string& path, std::list<rigtree*>::iterator& r);
		bool remove(Hash& hash);
		void clear();
		Hash next();
		bool unlock(Hash& hash, uint32_t stableheight);
		void unlock(std::list<rigtree*>::iterator& it, uint32_t stableheight);
		bool remove(std::list<rigtree*>::iterator& it);
		void eraseoldersigs(Hash& vrighash); 
		void eraseoldersigs(std::list<bundle>::iterator& sig_it, std::list<rigtree*>::iterator& r);
	};
		
/////////////////////////////////////////////////////////////////////////////	

	bool operator< (const Hash& lhs, const Hash& rhs);
	
	VirtualRig* rigify();
	bool verify(Hash message, Hash sig[64], Hash pub);
	bool check_virtual_difficulty(const Hash& h, const Hash& target, uint64_t& diff, uint64_t& th_diff);
	
	Hash gettarget();
	void settarget(const Hash& tar);
	
	bool mindif(const Hash& a, const Hash& b, const Hash& c);
	
}

#endif
