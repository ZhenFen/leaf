#include "timehash.h"
#include "CryptoNoteCore/Difficulty.h"
#include "CryptoNoteCore/CryptoNoteFormatUtils.h"
#include "CryptoNoteCore/Currency.h"
#include "CryptoNoteCore/CryptoNoteTools.h"
#include "Common/StringTools.h"
#include "P2p/LevinProtocol.h"
#include <CryptoNote.h>
#include <CryptoTypes.h>
#include "crypto/hash.h"
#include "System/ContextGroup.h"
#include "P2p/NetNode.h"
#include "Miner/Miner.h"
#include <cstdio>
#include <chrono> 
#include "crypto/crypto.h"
#include <array>
#include <algorithm>
#include "Serialization/BinaryOutputStreamSerializer.h"
#include "HashTree.h"
#include "Common/StringInputStream.h"
#include "Common/Base58.h"
#include "timehashtools.h"
#include "CryptoNoteCore/Blockchain.h"

//#include "CryptoNoteTools.h"

using namespace Logging;
using namespace Crypto;
using namespace Common;
using namespace CryptoNote;

namespace timehash{
	
/**/
//std::unordered_map<uint64_t,unsigned char> used;//---

std::atomic<Phase> phase;
std::atomic<char> thPhase;
//std::atomic<bool> timehashreceive;

std::mutex thl;
Hash mytimehash;



std::mutex dfl;
difficulty_type currentDifficulty;
difficulty_type externalDifficulty;

std::mutex lsl;
std::unordered_map<uint64_t, listtosend> liststosend;

HashTree tree;
Timehashes mytimehashes;
Timehashlists timehashlists;

Tickets tickets;
NodeServer* srv;

Crypto::cn_context m_cn_context;

Blockchain* blockchain;

void setchain(Blockchain* bc){
	blockchain = bc;
};

//timehash threadsafe handlers
Hash current_timehash(){
	thl.lock();
	Hash ret = mytimehash;
	thl.unlock();
	return ret;
};

void set_timehash(Hash newt){
	thl.lock();
	mytimehash=newt;
	thl.unlock();
};

//timing
bool miningtime(){
	return (phase==timehashtail || phase==mining);
}

bool normaloperationtime(){
	return (phase==normal);
}

void wait_for_timehash_start(){
	wait_for_next_timehash(INTERVAL);
}

void wait_for_next_timehash(int iv){
	auto starttimepoint = std::chrono::high_resolution_clock::now();
	auto starttimepoint_ms = std::chrono::time_point_cast<std::chrono::milliseconds>(starttimepoint);
	std::chrono::milliseconds starttime = starttimepoint_ms.time_since_epoch();
	std::chrono::milliseconds interval(iv);
	
	//time sync
	std::chrono::milliseconds timedifference=starttime+interval-(starttime%interval);
	std::chrono::time_point <std::chrono::high_resolution_clock> timepoint(timedifference);
	std::this_thread::sleep_until(timepoint);	
}

//timehash main loop, called from netnode.cpp main loop
void th_main(Logging::LoggerRef& logger, NodeServer* server){   //spawn this
  Hash myrnd;
  
  srv=server;

  wait_for_next_timehash(NET_LATENCY);
	//main loop for controlling all connections (on seperate threads) with atomic flags;
  for(;;){
	phase=normal;
	logger(INFO) << "Normal operation again...";
	
	generate_random_bytes(HASH_SIZE, myrnd.data);
	set_timehash(myrnd);
	mytimehashes.insert(current_timehash());
	
	wait_for_timehash_start();
	
	mytimehashes.clear();
	timehashlists.clear();
	tickets.restart();
	
	phase=timehash;
	logger(INFO) << "Now sending timehashes...";
	
	wait_for_next_timehash(NET_LATENCY);
	wait_for_next_timehash(NET_LATENCY);
	wait_for_next_timehash(NET_LATENCY);
	
	setinternaldifficulty();
	
	tree.init();
	tree.clear();
	
	//internal timehash loop controlling timehash phases
	for(thPhase=0; thPhase<12; thPhase++){
		tree.insert(myrnd);
		
		server->externalRelayNotifyToAll(TIME_HASH, HashtoBinaryArray(current_timehash()));
		logger(DEBUGGING) << "timehash  " << Tools::Base58::encode(Common::asString(current_timehash().data,HASH_SIZE)) << " sent!";
	
		logger(DEBUGGING) << "now receiving...";
		wait_for_next_timehash(NET_LATENCY);
		
		logger(DEBUGGING) << "now connecting timehashes to one root...";
		tree.connectalltoroot();
				
		set_timehash(tree.getroot());
		
		mytimehashes.insert(current_timehash());
		
		preparestringlists(logger);
		
		tree.clear();
		wait_for_next_timehash(NET_LATENCY);
	}
	
	phase=timehashtail;
	
	wait_for_next_timehash(NET_LATENCY);
	wait_for_next_timehash(NET_LATENCY);
	wait_for_next_timehash(NET_LATENCY);//pf.. dirt
	
	sendstringlists(logger);
		
	logger(INFO) << "miners mine and we receive tickets...";
	phase=mining;
	wait_for_next_timehash(30000);
	
	phase=miningtail;
	wait_for_next_timehash(3000);
  }
}

//lists of hashes paths inside timehash tree constructed as strings
void preparestringlists(Logging::LoggerRef& logger){
	lsl.lock();
	for(auto it=liststosend.begin();it!=liststosend.end();it++){
		if(thPhase==0){
			it->second.str.clear();
			it->second.str.push_back((const char)0);
		}
		if(it->second.entry!=0)
			tree.addpath(it->second.str, it->second.entry);
		logger(DEBUGGING)<< "Peer " << it->second.ctx->peerId <<"is about to SEND STRING: "<<Tools::Base58::encode(it->second.str);
	}
	lsl.unlock();
};

void sendstringlists(Logging::LoggerRef& logger){
	BinaryArray data;
	lsl.lock();
	for(auto it=liststosend.begin();it!=liststosend.end();it++){
		data=StringtoBinaryArray(it->second.str);
		
		it->second.ctx->pushMessage(P2pMessage(P2pMessage::NOTIFY, TIME_HASH_LISTS, data, 1));
		
		logger(DEBUGGING)<< "Peer " << it->second.ctx->peerId <<"is about to SEND STRING: "<<Tools::Base58::encode(it->second.str);
	}
	liststosend.clear();
	lsl.unlock();
};

//external handler called from miner when a block mined, to construct and relay a ticket
void handle_ticket_found(Crypto::Hash& prev, Crypto::Hash& fast, Crypto::Hash& pow, Logging::LoggerRef& logger){
	std::string ticket;
	
	ticket  = Common::asString(fast.data,32);
	ticket += Common::asString(prev.data,32);
	ticket.push_back((const char)0);
	
	//relay notify ticket
	srv->externalRelayNotifyToAll(TICKET, timehash::StringtoBinaryArray(ticket));
	logger(DEBUGGING) << "ticket  " << Tools::Base58::encode(ticket) << " sent!";
		
	//construct and save ticket internally
	//Hash title;
	//std::copy(ticket.begin(), ticket.begin()+HASH_SIZE, title.data);
	
	tickets.insert(fast);
}

//difficulty thread safe handlers
void setdifficulty(difficulty_type& Difficulty){//called from blockchain.cpp to set difficulty 
	dfl.lock();
		externalDifficulty=Difficulty;
	dfl.unlock();
};

void setinternaldifficulty(){//called from blockchain.cpp to set difficulty 
	dfl.lock();
		currentDifficulty = externalDifficulty*9/10;
	dfl.unlock();
};

bool checkdifficulty(Hash& hash){
	dfl.lock();
	bool ret = check_hash(hash, currentDifficulty);
	dfl.unlock();
	return ret;
};

//call this from inside netnode.cpp input loop of every connection handled=timehash_protocol(ctx,cmd, thp);
bool timehash_protocol(P2pConnectionContext& ctx,LevinProtocol::Command& cmd, Logging::LoggerRef& logger, int& returncode){
	Hash timeHash;

	//timehash receiving
	if(cmd.command==TIME_HASH){
		cmd.isNotify=true;
		cmd.isResponse=false;
		if(phase!=timehash && phase!=timehashtail){
			logger(ERROR, BRIGHT_RED) << "timehash command came out of time " << ctx.peerId << ": drop connection... (check your systemtime if you see this continuously)";
				ctx.m_state = CryptoNoteConnectionContext::state_shutdown;
				return true;
			};
		//if(used[ctx.peerId]>20){
		//	logger(ERROR, BRIGHT_RED) << "Peer " << ctx.peerId << " tried to send more timehashes drop connection... (check your systemtime if you see this continuously)";
		//	ctx.m_state = CryptoNoteConnectionContext::state_shutdown;
		//	return false;
		//}
		logger(DEBUGGING) << "Connection "<< ctx.peerId << "is receiving timehash";
		if(!handle_incoming_timehash(ctx, cmd, timeHash)){
			logger(ERROR, BRIGHT_RED) << "failed to parse timehash from peer " << ctx.peerId << "...drop connection";
			ctx.m_state = CryptoNoteConnectionContext::state_shutdown;
			return true;
		};
		logger(DEBUGGING) << "Connection "<< ctx.peerId << " received timehash: " << Tools::Base58::encode(Common::asString(timeHash.data,HASH_SIZE)) ;
		return true;
	}
	//timehashlist receiving
	else if(cmd.command==TIME_HASH_LISTS){
		cmd.isNotify=true;
		cmd.isResponse=false;
		if(phase!=mining && phase!=timehashtail){
			logger(ERROR, BRIGHT_RED) << "timehashlist came out of time " << ctx.peerId << ": drop connection... (check your systemtime if you see this continuously)";
				ctx.m_state = CryptoNoteConnectionContext::state_shutdown;
				return true;
			};
			
		if(!handle_timehash_lists(cmd)){
			logger(ERROR, BRIGHT_RED) << "failed to parse timehashlists from peer " << ctx.peerId << "...drop connection";
			ctx.m_state = CryptoNoteConnectionContext::state_shutdown;
		};
		return true;
	}
	//ticket receiving
	else if(cmd.command==TICKET){
		cmd.isNotify=true;
		cmd.isResponse=false;
		if(phase!=timehashtail && phase!=mining && phase!=miningtail){
			logger(ERROR, BRIGHT_RED) << "ticket came out of time " << ctx.peerId << ": drop connection... (check your systemtime if you see this continuously)";
				ctx.m_state = CryptoNoteConnectionContext::state_shutdown;
				return true;
			};
		if(!handle_incoming_ticket(ctx, cmd, logger)){
			logger(ERROR, BRIGHT_RED) << "failed to parse ticket from peer " << ctx.peerId << "...drop connection";
			ctx.m_state = CryptoNoteConnectionContext::state_shutdown;
		};
		return true;
	};
	return false;
};


bool handle_timehash_lists(LevinProtocol::Command& cmd){
	std::string str;
	if(!BinaryArraytoString(cmd.buf,str))
		return false;
	
	if(!verifypaths(str, mytimehashes, timehashlists)){
		return false;
	}
	return true;
}
	
bool handle_incoming_timehash(P2pConnectionContext& ctx, LevinProtocol::Command& cmd, Hash& timeHash)
{
	void* pointer;
	
	if(!BinaryArraytoHash(cmd.buf, timeHash))
		return false;
	
	if(!tree.insert(timeHash, pointer))//add pointer/cout
		return true;
		
	lsl.lock();
	liststosend[ctx.peerId].ctx=&ctx;
	liststosend[ctx.peerId].entry=pointer;
	//used[ctx.peerId]++;
	lsl.unlock();
	return true;
}

bool handle_incoming_ticket(P2pConnectionContext& ctx,LevinProtocol::Command& cmd, Logging::LoggerRef& logger)
{ 
	std::string str;
	Hash prevHash, title, pow, res;
	if(!BinaryArraytoString(cmd.buf,str)){
		logger(ERROR, BRIGHT_RED) << "failed to parse ticket from " << ctx.peerId << "...drop connection";
		return false;
	}
	
	if(str.size()!=2*HASH_SIZE+1){
		logger(ERROR, BRIGHT_RED) << "incorrect ticket size from " << ctx.peerId << "...drop connection";
		return false;
	}
	
	unsigned char hops=str.back();
	if(hops>20){
		logger(ERROR, BRIGHT_RED) << "received ticket after more than 20 hops from " << ctx.peerId << "...drop connection";
		return false;
	}
	str.pop_back();
	
	logger(DEBUGGING) << "received ticket: " << Tools::Base58::encode(str) << " from " << ctx.peerId;
	
	std::copy(str.begin(), str.begin()+HASH_SIZE, title.data);
	
	if(tickets.haveticket(title))
		return true;
		
	std::copy(str.begin()+HASH_SIZE, str.end(), prevHash.data);
	
	if(tickets.ready())//in case we now initialize
		if(!blockchain->haveBlock(prevHash)){
			logger(ERROR, BRIGHT_RED) << "received ticket " << Tools::Base58::encode(str) << " from " << ctx.peerId << " has no reference in stored tickets ...drop connection";
			return false;
		}
	
	uint8_t hashes[2*HASH_SIZE];
			
	memcpy(hashes,title.data,HASH_SIZE);
	memcpy(hashes+HASH_SIZE,prevHash.data, HASH_SIZE);
  
	cn_slow_hash(m_cn_context, hashes, 2*HASH_SIZE, pow);	
	
	if(!checkdifficulty(pow)){
		logger(ERROR, BRIGHT_RED) << "received ticket " << Tools::Base58::encode(str) << " has not enough difficulty from " << ctx.peerId << "...drop connection";
		return false;
	}
		
	str.push_back(hops+1);
	
	if(hops<20)
		if(tickets.ready())	
			srv->externalRelayNotifyToAll(TICKET, timehash::StringtoBinaryArray(str));
	
	if(phase==miningtail)
		tickets.insertlate(title);
	else
		tickets.insert(title);
	
	return true;
}	

//called from core.cpp to check if a block has a ticket to enter blockchain and be relayed
std::mutex checkmut;
bool checked;
bool tocheck;

void releasecheckmut(){
	checkmut.unlock();
}

bool checkticket(Hash& blockhash, Logging::LoggerRef& logger, bool tickettime){
	if (!tocheck)
		return true;
	
	if (!checked)
		return false;;
	
	if (!tickettime)
		return true;
	
	//contained in tickets
	logger (DEBUGGING) << "Now checking incoming block fortickets";
	if(!tickets.havecurrentticket(blockhash)){
		if(!tickets.havelateticket(blockhash)){
			logger(ERROR, BRIGHT_RED) << "received block does not have valid ticket to enter blockchain";
			return false;
		}
	}
	return true;
}

void checktimehash(Block& b, Hash& blockhash, Logging::LoggerRef& logger, bool relayblock){
	checkmut.lock();
	tocheck = relayblock;
	if (!tocheck)
		return;
		
 	checked = false;//!!!
	
	//validate timehash with timehashchain //add mylist to timehashchain  
	if(!verifypathchain(b.TimeHash, b.timeHashChain, mytimehashes, timehashlists)){
		logger(ERROR, BRIGHT_RED) << "impossible to verify timehashchain in received block";
		return;
	}
	
	//add ticket to valid..
	tickets.validate(blockhash);
	
	//dont accept block if over 10 timehash hops (although ticket accepted for later use)
	if(b.timeHashChain.back()>10)
		return;
	
	checked = true;
}	

//external ticket handler called from core.cpp when block verification fails in order to erase its ticket
void eraseinvalidticket(Hash& blockhash){
	tickets.invalidate(blockhash);
}

}//namespace timehash

