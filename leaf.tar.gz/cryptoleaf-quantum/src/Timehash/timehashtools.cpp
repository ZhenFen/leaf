#include "CryptoNoteCore/Difficulty.h"
#include "CryptoNoteCore/CryptoNoteFormatUtils.h"
#include "CryptoNoteCore/Currency.h"
#include "CryptoNoteCore/CryptoNoteTools.h"
#include "Common/StringTools.h"
#include "P2p/LevinProtocol.h"
#include <CryptoNote.h>
#include <CryptoTypes.h>
#include "crypto/hash.h"
#include "System/ContextGroup.h"
#include "P2p/NetNode.h"
#include "Miner/Miner.h"
#include <cstdio>
#include <chrono> 
#include "crypto/crypto.h"
#include <array>
#include <algorithm>
#include "Serialization/BinaryOutputStreamSerializer.h"
#include "HashTree.h"
#include "Common/StringInputStream.h"
#include "Common/Base58.h"
#include "timehashtools.h"

//#include "CryptoNoteTools.h"

using namespace Logging;
using namespace Crypto;
using namespace Common;
using namespace CryptoNote;

namespace timehash{

//class Tickets

void Tickets::restart(){
	mut.lock();
	tickets.clear();
	mut.unlock();
}

bool Tickets::ready(){
	bool empty;
	mut.lock();
	empty=validprevioustickets.empty();
	mut.unlock();
	return !empty;
}	

void Tickets::insert(Hash& title){
	mut.lock();
	tickets.push_back(title);
	mut.unlock();
}	

void Tickets::insertlate(Hash& title){
	mut.lock();
	latetickets.push_back(title);
	mut.unlock();
}	

void Tickets::validate(Hash& title){
	mut.lock();
	validprevioustickets.push_back(title);
	mut.unlock();
}	
	
bool Tickets::haveticket(Hash& title, std::list<Hash>& tickets){
	mut.lock();

	if(std::find(tickets.begin(), tickets.end(), title)!=tickets.end()){//if this ticket is contained in list
		mut.unlock();
		return true;
	}
	
	mut.unlock();
	return false;
}	

bool Tickets::havecurrentticket(Hash& title){
	return haveticket(title, tickets);
}	

bool Tickets::havelateticket(Hash& title){
	return haveticket(title, latetickets);
}	

bool Tickets::havepreviousticket(Hash& title){
	return haveticket(title, validprevioustickets);
}	
	
bool Tickets::haveticket(Hash& title){
	if(!haveticket(title, tickets))
		if(!haveticket(title, latetickets))
			if(!haveticket(title, validprevioustickets))
				return false;
	return true;	
}	
	
void Tickets::invalidate(Hash& blockhash){
	mut.lock();
	auto it = std::find(validprevioustickets.begin(), validprevioustickets.end(), blockhash);
	if(it != validprevioustickets.end())
		validprevioustickets.erase(it);
	mut.unlock();
}

//Timehashes
bool Timehashes::find(std::string& str){
	bool ret;
	mut.lock();
	ret = (mytimehashes.find(str)!=mytimehashes.end());
	mut.unlock();
	return ret;
}

void Timehashes::clear(){
	mut.lock();
	mytimehashes.clear();
	mut.unlock();
}

void Timehashes::insert(Hash th){
	mut.lock();
	mytimehashes.insert(Common::asString(th.data,HASH_SIZE));
	mut.unlock();
	//std::cout << Tools::Base58::encode(Common::asString(th.data,HASH_SIZE)) << " inserted in timehashlists\n";
}

//Timehashlists
bool Timehashlists::find(std::string& str, std::string& result){
	bool ret=true;
	mut.lock();
	auto it=timehashlists.find(str);
	if(it==timehashlists.end())
		ret=false;
	else
		result=it->second;
	mut.unlock();
	return ret;
}

void Timehashlists::clear(){
	mut.lock();
	timehashlists.clear();
	mut.unlock();
}

void Timehashlists::insert(std::string& first, std::string& second){
	mut.lock();
	timehashlists[first]=second;
	mut.unlock();
}

//serialization tools
BinaryArray StringtoBinaryArray(std::string& str){
	BinaryArray binaryArray;
	
	Common::VectorOutputStream stream(binaryArray);
	BinaryOutputStreamSerializer serializer(stream);
	serializer(str, "");
	
	return binaryArray;
}

BinaryArray HashtoBinaryArray(Hash hash){
	std::string str=Common::asString(hash.data,HASH_SIZE);
	return StringtoBinaryArray(str);
};

bool BinaryArraytoString(BinaryArray& binaryArray, std::string& str){
	try {
		std::string instream = Common::asString(binaryArray.data(),binaryArray.size());
		Common::StringInputStream stream(instream);
		BinaryInputStreamSerializer serializer(stream);
		serializer(str, "");
	} catch (std::exception&) {}

	if(str.size()==0) // check that some data was consumed
		return false;
	return true;
}

bool BinaryArraytoHash(BinaryArray& binaryArray, Hash& hash){
	std::string str;
	BinaryArraytoString(binaryArray, str);
	std::copy(std::begin(str),std::end(str),std::begin(hash.data));
	return true;
}

}//namespace timehash


