/*extern "C"{
	#include "crypto/hash-ops.h"
}*/
#include <CryptoTypes.h>
#include <list>
#include <map>
#include <stdio.h>
#include <iostream>
#include <iterator>
#include <thread>

#ifndef HASHOPS
#define HASHOPS
extern "C"{
	#include "crypto/hash-ops.h"
}
#endif

#include "HashTree.h"
#include "keccakdrbg.h"
#include "hashsig.h"
//#include "CryptoNoteCore/CryptoNoteFormatUtils.h"
#include "Common/StringTools.h"
//#include "CryptoNoteCore/Difficulty.h"
#include "Common/Base58.h" //erase this line

#define HASH_SIZE 32
#define CONFIRMATION_DISTANCE 6
//#define POB_BLOCKS 2

using namespace Crypto;

namespace timehash{
	
	bool operator== (const Hash& lhs, const Hash& rhs){
		if((uint64_t)(*(lhs.data))!=(uint64_t)(*(rhs.data))) 
			return false;
		if((uint64_t)(*(lhs.data+8))!=(uint64_t)(*(rhs.data+8))) 
			return false;
		if((uint64_t)(*(lhs.data+16))!=(uint64_t)(*(rhs.data+16))) 
			return false;
		if((uint64_t)(*(lhs.data+24))!=(uint64_t)(*(rhs.data+24))) 
			return false;
		return true;
	}
	
	bool operator< (const Hash& lhs, const Hash& rhs){
		if((uint64_t)(*(lhs.data))!=(uint64_t)(*(rhs.data))) 
			return (uint64_t)(*(lhs.data))<(uint64_t)(*(rhs.data));
		if((uint64_t)(*(lhs.data+8))!=(uint64_t)(*(rhs.data+8))) 
			return (uint64_t)(*(lhs.data+8))<(uint64_t)(*(rhs.data+8));	
		if((uint64_t)(*(lhs.data+16))!=(uint64_t)(*(rhs.data+16))) 
			return (uint64_t)(*(lhs.data+16))<(uint64_t)(*(rhs.data+16));	
		if((uint64_t)(*(lhs.data+24))!=(uint64_t)(*(rhs.data+24))) 
			return (uint64_t)(*(lhs.data+24))<(uint64_t)(*(rhs.data+24));			
		return false;
	}
	
	std::mutex mut;
	
	VirtualRig myrig;

	std::mutex tmut;
	Hash Target;
	
	void settarget(const Hash& tar){
		tmut.lock();
		Target = tar;
		tmut.unlock();
	}
	
	Hash gettarget(){
		tmut.lock();
		Hash tar = Target;
		tmut.unlock();
		return tar;
	}
	 
	VirtualRig* rigify(){
		myrig.mut.lock();
		myrig.initialized = false;
		myrig.mut.unlock();
		return &myrig;
	}
	
		
	bool check_virtual_difficulty(const Hash& h, const Hash& target, uint64_t& diff, uint64_t& th_diff){
		//just fun, never liked the easy way, if you are serious change this
		Hash upperbound, lowerbound;
		uint32_t i;
		uint32_t m = 0;
		uint8_t max = 255;
		uint8_t min = 0;
		std::fill(upperbound.data, upperbound.data + HASH_SIZE, 255);
		std::fill(lowerbound.data, lowerbound.data + HASH_SIZE, 0);///?????
		
		for(i=0; (i+1)*32 < diff; i++){
			lowerbound.data[i] = target.data[i];
			upperbound.data[i] = target.data[i];
		}
		
		if(h < lowerbound )
			return false;
		if(upperbound < h)
			return false;
		uint32_t r = diff - i*32;	
		
		for(i++; i<32; i++){
			lowerbound.data[i] = target.data[i];
			upperbound.data[i] = target.data[i];
			if(h < lowerbound)
				break;
			if(upperbound < h)
				break;
		}	
		
		uint32_t g;
		m = (i - 1) * 32;
		
		if(h.data[i] < target.data[i])
			g = target.data[i] - h.data[i];
								
		if(target.data[i] < h.data[i])
			g = h.data[i] - target.data[i];
				
		if(m < diff)
			if(r < g)
				return false;
		th_diff = m + g;
		
		return true;
	}
		
	
	//HashSig functions	
	void HashSig::init(void* cn_data, char* seed, size_t size){
		keys.clear();
		drbg.seed(cn_data, seed, size);
		tree.init();
	}
	
	void HashSig::add(){
		Hash pub;
		add(pub);
	}
	
	void HashSig::add(Hash& pub){
		keypair pair;
		Hash temp1, temp2;
		
		//fill private key data
		for(int i=0; i<64; i++)
			pair.priv[i]=drbg.rand();
		
		//compute public key
		for(int i=0; i<64; i++){
			temp1 = pair.priv[i];
			
			//winternitch chains
			for(int j=0; j<128; j++){
				cn_fast_hash((void*)temp1.data, HASH_SIZE, (char*)temp2.data);
				cn_fast_hash((void*)temp2.data, HASH_SIZE, (char*)temp1.data);
			}
			tree.insert(temp1);
		}
		tree.connectalltoroot();
		pub=tree.getroot();
		pair.pub=pub;
		
		//put into list
		keys.push_back(pair);
		
		tree.clear();
	}
	
	bundle HashSig::add8(){
		bundle b;
		Hash temp;
		HashTree t;
		t.init();
		for(int i = 0; i < 8; i ++){
			add(temp);
			t.insert(temp);
			b.children[i] = temp;
		}
		t.connectalltoroot();
		b.root = t.getroot();
		b.used = 0;	
		t.clear();
		return b;	
	}
	
	void HashSig::reseed(Hash& hash){
		drbg.restart();
		drbg.reseed((char*)hash.data, HASH_SIZE);
	}
	
	bool HashSig::sign(Hash& message, Hash& pub, Hash sig[64]){
		 std::list<Hash> next;
		 return sign(message, pub, sig, 0, next);
	}
	
	bool HashSig::sign(Hash& message, Hash& pub, Hash sig[64], int numberofnextsigs, std::list<Hash>& next){
		//search for the keypair with the appropriate public key
		std::list<keypair>::iterator it;
		if(!search(pub,it))
			return false;
		
		keypair& pair= *it;
		
		//embed next signature bublic keys
		Hash temp;		
		HashTree tree;
		tree.init();
		tree.insert(message);		//start computing new message hash with next signatures
		
		for(int n = 0; n < numberofnextsigs; n++){  
			add(temp);				//add new keypair to internal memory
			next.push_back(temp);   //insert next signature public keys to the list to return
			tree.insert(temp);		//embed next signature public keys to the message hash
		}
		tree.connectalltoroot();	//compute new messsage hash
		message=tree.getroot();
		tree.clear();
		
		//compute signature
		Hash A;
		Hash B;
		Hash* a = &A;
		Hash* b = &B;
		for(int i=0; i<32; i++){
			//compute winternitch chains
			*a = pair.priv[i*2];
			for(int j = 0; j <= message.data[i]; j++){
				cn_fast_hash((void*)(a->data), HASH_SIZE, (char*)(b->data));
				std::swap(a, b);
			}
			sig[i*2] = *a;
			
			*a = pair.priv[i*2+1];
			for(int j = 255; j >= message.data[i]; j--){
				cn_fast_hash((void*)(a->data), HASH_SIZE, (char*)(b->data));
				std::swap(a, b);
			}
			sig[i*2+1] = *a;
		}	
		return true;
	}
	
	bool HashSig::search(Hash& hash, std::list<keypair>::iterator& it){
		//search for the keypair with the appropriate public key
		for(it=keys.begin(); it!=keys.end(); ++it)
			if(it->pub==hash)
				break;
		
		return (it!=keys.end());
	}
	
	bool HashSig::remove(Hash& hash){
		//search for the keypair with the appropriate public key
		std::list<keypair>::iterator it;
		if(!search(hash,it))
			return false;
		
		keys.erase(it);
		
		return true;
	}
	
	void HashSig::clear(){
		keys.clear();
	}
	
	//external functions
	bool verify(Hash message, Hash sig[64], Hash pub){
		HashTree tree;
		tree.init();
		
		//compute public key from signature according to message
		Hash A;
		Hash B;
		Hash* a = &A;
		Hash* b = &B;
		for(int i=0; i<32; i++){
			//compute winternitch chains
			*a = sig[i*2];
			for(int j = message.data[i]; j < 255; j++){
				cn_fast_hash((void*)(a->data), HASH_SIZE, (char*)(b->data));
				std::swap(a, b);
			}
			tree.insert(*a);
			
			*a = sig[i*2+1];
			for(int j = message.data[i]; j > 0; j--){
				cn_fast_hash((void*)(a->data), HASH_SIZE, (char*)(b->data));
				std::swap(a, b);
			}
			tree.insert(*a);
		}
		tree.connectalltoroot();
		bool ret = (pub==tree.getroot());
		tree.clear();
		return ret;	
	}
	
	//HashSig functions	
	void VirtualRig::init(void* cn_data, std::string str){
		if(str.size() < 32)
			return;
		char* key = (char*)malloc(str.size());
		std::copy(str.begin(), str.end(), key);
		init(cn_data, key, str.size());
		free(key);
	}
	
	void VirtualRig::init(void* cn_data, char* seed, size_t size){
		mut.lock();
		initialized = false;
		keys.clear();
		//Sig.init(cn_data, seed, size);
		cnd=cn_data;
		
		drbg.seed(cn_data, seed, HASH_SIZE);
		drbg.reseed(seed, HASH_SIZE);
		
		trees.clear();
		
		for(int i = 0; i < 6; i++)
			add();
				
		last = trees.begin();
		
		initialized = true;
		mut.unlock();
	}
		
	Hash VirtualRig::add(){
		Hash pub;
		add(pub, cnd);
		return pub;
	}
	
	Hash VirtualRig::add(void* cndata){
		Hash pub;
		add(pub, cndata);
		return pub;
	}
	
	void VirtualRig::add(Hash& pub){
		add(pub, cnd);
	}
	
	void VirtualRig::add(Hash& pub, void* cndata){
		rigtree* rig = new rigtree;
		rig->tree = new HashTree;
		rig->tree->init();
		rig->Sig.init(cndata, (char*)drbg.rand().data, HASH_SIZE);
		Hash temp;
		
		//create signatures
		for(int n = 0; n < 6; n++)
			rig->sigs.push_back(rig->Sig.add8());
		
		rig->initSig = rig->sigs.begin();
		rig->lastSig = rig->initSig;
		
		//compute large hash tree
		void* p;
		for(int i=0; i<1024; i++){
			temp=drbg.rand();
			rig->tree->insert(temp, p);
			(rig->keys)[temp]=p;
		}
		//insert signatures 
		rig->tree->insert(rig->lastSig->root);
		rig->tree->connectalltoroot();
		
		pub=rig->tree->getroot();
				
		//put into list
		trees.push_back(rig);
	}
	
	bool VirtualRig::searchRoot(const Hash& hash, std::list<rigtree*>::iterator& it){
		//search for the root
		for(it=trees.begin(); it!=trees.end(); ++it)
			if((*it)->tree->getroot() == hash)
				break;
		
		return (it!=trees.end());
	}
	
	bool VirtualRig::sigsearch(Hash& hash, std::list<bundle>::iterator& it, std::list<rigtree*>::iterator& r){
		//search for the keypair with the appropriate public key
		for(r=trees.begin(); r!=trees.end(); ++r)
			for(it=(*r)->sigs.begin(); it!=(*r)->sigs.end(); ++it)
				if(it->root == hash)
					return true;
		
		return false;
	}
	
	void VirtualRig::nextsig(Block& block, rigtree* r){
		//place next signature
		block.VirtualMiningRig = std::next(r->lastSig)->root;
	}
	
	bool VirtualRig::constructblock(Block& block, Hash target, uint64_t& diff, std::string& path, std::list<rigtree*>::iterator& r){
		//if we mine block put evidence on path 
		if(!closeto(target, path, diff))
			return false;
		
		//restore roothash from path
		Hash roothash;
		std::copy(path.end() - HASH_SIZE - 1, path.end() - 1, roothash.data);
		
		//find rigtree entry
		if(!searchRoot(roothash, r))
			return false;
			
		//add height to path	
		uint32_t height = (*r)->height;
		path.resize(path.size()+4);
		std::copy(&height, &height+4, path.end()-4);
		
		//put next signature into block
		nextsig(block, *r);
		
		return true;
	} 
	
	bool VirtualRig::finishblock(Block& block, Hash& blockhash, std::string& path, std::list<rigtree*>::iterator& r){
		//sign the block
		Hash sig[64];
		uint8_t i = (*r)->lastSig->used++; //mark subsignature as used
		if( i>=8 )
			return false;
		(*r)->Sig.sign(blockhash, (*r)->lastSig->children[i], sig);	//sign //????????????????????!!!!!!!!!!!!!???????sig of rig
		
		for(int x = 63; x >= 0; x--)
			block.rignature += Common::asString(sig[x].data, HASH_SIZE); 	//transfer signature in rignature
		//print
		std::string signat;
		for(int x = 0; x < 64; x++)
			signat += Common::asString(sig[x].data, HASH_SIZE); 	
		
		//reconstruct signature add8 tree
		HashTree t;
		t.init();
		void* p;
		void* start;
		for(int x = 0; x < 8; x++){
			t.insert((*r)->lastSig->children[x], p);
			if(x == i)
				start = p;
		}
		t.connectalltoroot();
		std::string pathtopub = t.lonelypath(start);
		t.clear();
		
		if((*r)->lastSig == (*r)->initSig){	//if this signature is inside rigtree
			char counter = pathtopub.back();
			pathtopub.pop_back();
			pathtopub.resize(pathtopub.size() + (2*HASH_SIZE));
			std::copy(path.end() - (3*HASH_SIZE+5), path.end() - 5, pathtopub.end() - 3*HASH_SIZE);
			pathtopub.push_back(++counter);
		}
		
		//check L or R? 
		Hash check;
		std::copy(pathtopub.begin(), pathtopub.begin() + HASH_SIZE, check.data);
		if(check == (*r)->lastSig->children[i])
			block.rignature += 'L';
		else
			block.rignature += 'R';
		
		//merge pathtopub to rignature
		block.rignature += pathtopub;
		
		//copy signature height to rignature
		block.rignature.resize(block.rignature.size() + 4);
		std::copy(&((*r)->lastSig->height), &((*r)->lastSig->height) + 4, block.rignature.end() - 4);
			
		//merge path which proves mining to rignature
		block.rignature += path;
		return true;
	} 
	
	bool VirtualRig::closeto(Hash& hash, std::string& path, uint64_t& diff){
		if(keys.empty())
			return false;
		void* z = 0;
		auto ret = keys.insert(std::pair<Hash, void*>(hash, z));
		auto it = ret.first;
		auto rm=it;
				
		Hash a, b; 
		if(it==keys.begin())
			it++;
		else if(it==std::prev(keys.end()))
			it--;
		else if(it->second==z){
			if(mindif(std::next(it)->first, it->first, std::prev(it)->first))
				it++;
			else it--;
		}
			
		if(!ret.second) //incredible situation, the universe is about to collapse
			it=rm;
		
		uint64_t th_diff;
		uint64_t d = diff;
		if(!check_virtual_difficulty(it->first, hash, d, th_diff))
			return false;
		path = ht.lonelypath(it->second);
		
		if(rm->second==z)
			keys.erase(rm);
				
		return true;
	}
	
	bool VirtualRig::remove(Hash& hash){
		//search for the keypair with the appropriate public key
		std::list<rigtree*>::iterator it;
		if(!searchRoot(hash,it))
			return false;
			
		remove(it);		
		return true;	
	}
	
	bool VirtualRig::remove(std::list<rigtree*>::iterator& it){	
		(*it)->tree->clear();
		delete (*it)->tree;
		(*it)->keys.clear();
		(*it)->Sig.clear();
		(*it)->sigs.clear();
		trees.erase(it);
		
		return true;
	}
	
	void VirtualRig::clear(){
		for(auto it=trees.begin(); it!=trees.end(); ++it)
			remove(it);
	}
	
	bool VirtualRig::unlock(Hash& hash, uint32_t stableheight){
		std::list<rigtree*>::iterator it;
		if(!searchRoot(hash, it))
			return false;
		
		unlock(it, stableheight);	
		return true;
	}
	
	void VirtualRig::unlock(std::list<rigtree*>::iterator& it, uint32_t stableheight){
		(*it)->height = stableheight;
		(*it)->initSig->height = stableheight;
		keys.insert((*it)->keys.begin(), (*it)->keys.end());		/////delete old
	}
	
	Hash VirtualRig::next(){
		mut.lock();
		while(initialized == false)
			std::this_thread::sleep_for(std::chrono::milliseconds(100));
		////////////////
		Hash ret; 
		//if(std::next(last) != trees.end())
			ret = (*std::next(last))->tree->getroot();
		
		mut.unlock();
		
		return ret;
	}
	
	
	void VirtualRig::eraseoldersigs(Hash& vrighash){//////////older than last_sig
		std::list<bundle>::iterator sig_it;
		std::list<rigtree*>::iterator r;
		if(!sigsearch(vrighash, sig_it, r))
			return;
		//eraseoldersigs(sig_it, r); //rework
	}
	
	void VirtualRig::eraseoldersigs(std::list<bundle>::iterator& sig_it, std::list<rigtree*>::iterator& r){
		bool cont = (sig_it != (*r)->sigs.begin());
		
		while(cont) {
			sig_it--;
			for(int i; i<8; i++)
				(*r)->Sig.remove(sig_it->children[i]);
			
			cont = (sig_it != (*r)->sigs.begin());
			(*r)->sigs.erase(sig_it);
		} 
	}
	
	bool mindif(const Hash& a, const Hash& b, const Hash& c){
		uint64_t a_b = ((uint64_t)(*(a.data))-(uint64_t)(*(b.data)));
		uint64_t b_c = ((uint64_t)(*(b.data))-(uint64_t)(*(c.data)));
		if(a_b!=b_c )
			return (a_b<b_c);
		
		a_b = ((uint64_t)(*(a.data+8))-(uint64_t)(*(b.data+8)));
		b_c = ((uint64_t)(*(b.data+8))-(uint64_t)(*(c.data+8)));
		if(a_b!=b_c )
			return (a_b<b_c);
		
		a_b = ((uint64_t)(*(a.data+16))-(uint64_t)(*(b.data+16)));
		b_c = ((uint64_t)(*(b.data+16))-(uint64_t)(*(c.data+16)));
		if(a_b!=b_c )
			return (a_b<b_c);
		
		a_b = ((uint64_t)(*(a.data+24))-(uint64_t)(*(b.data+24)));
		b_c = ((uint64_t)(*(b.data+24))-(uint64_t)(*(c.data+24)));
		if(a_b!=b_c )
			return (a_b<b_c);	
		
		return false;
	}
}

