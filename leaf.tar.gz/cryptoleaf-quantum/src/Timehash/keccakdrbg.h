#include <CryptoTypes.h>

#include <stdio.h>

#include <iostream>


#ifndef KECCAK_DRBG
#define KECCAK_DRBG

using namespace Crypto; 

namespace timehash{
	
	class KeccakDrbg{
		Hash C;
		char V[2*HASH_SIZE];
		Hash Cback;
		char Vback[2*HASH_SIZE];
		void* cn_ctx_data;
	  public:
		void seed(void* cn_data, char* s, size_t size);
		Hash rand();
		void reseed(char* s, size_t size);
		void restart();
	};
	
}
 #endif
