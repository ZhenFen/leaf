
#include "CryptoNoteCore/CryptoNoteFormatUtils.h"
#include "CryptoNoteCore/Currency.h"
#include "CryptoNoteCore/CryptoNoteTools.h"
#include "P2p/LevinProtocol.h"
#include <CryptoNote.h>
#include <CryptoTypes.h>
#include "crypto/hash.h"
#include <System/ContextGroup.h>
#include "P2p/NetNode.h"
#include <cstdio>
#include <chrono> 
#include <vector>
#include <unordered_map>
#include <set>
#include "timehashtools.h"
#include "CryptoNoteCore/Difficulty.h"
#include "CryptoNoteCore/Blockchain.h"

#ifndef TIMEHASH_H
#define TIMEHASH_H

#define NET_LATENCY 400
#define MINING_DURATION 5200

#define INTERVAL 60000

//command codes
#define TIME_HASH 2096
#define TIME_HASH_LISTS 2097
#define TICKET 2098

#define MAX_TICKETS_NUMBER 256

#define EXPECTED_DIFFICULTY 1

//todo list

//includes
//check all again
//to all changed here, ifndefs

using namespace Crypto;
using namespace Common;
using namespace CryptoNote;

namespace  timehash{

	enum  Phase { timehash, timehashtail, mining, miningtail, normal };
	
	struct listtosend{
		P2pConnectionContext* ctx;
		void* entry;
		std::string str;
	};
		
	void setchain(Blockchain* bc);
	
	Hash current_timehash();
	void set_timehash(Hash newt);
	
	bool miningtime();
	bool normaloperationtime();
	void wait_for_timehash_start();
	void wait_for_next_timehash(int);
	
	void th_main(Logging::LoggerRef& logger,NodeServer* server);
	
	void preparestringlists(Logging::LoggerRef& logger);
	void sendstringlists(Logging::LoggerRef& logger);
		
	void handle_ticket_found(Crypto::Hash& prev, Crypto::Hash& fast, Crypto::Hash& pow, Logging::LoggerRef& logger);
	
	void setdifficulty(difficulty_type& Difficulty);
	void setinternaldifficulty();
	bool checkdifficulty(Hash& hash);
	
	bool timehash_protocol(P2pConnectionContext& ctx,LevinProtocol::Command& cmd, Logging::LoggerRef& logger, int& returncode);
	bool handle_timehash_lists(LevinProtocol::Command& cmd);
	bool handle_incoming_timehash(P2pConnectionContext& ctx, LevinProtocol::Command& cmd, Hash& timeHash);
	bool handle_incoming_ticket(P2pConnectionContext& ctx,LevinProtocol::Command& cmd, Logging::LoggerRef& logger);
	
	void releasecheckmut();
	bool checkticket(Hash& blockhash, Logging::LoggerRef& logger, bool tickettime);
	void checktimehash(Block& b, Hash& blockhash, Logging::LoggerRef& logger, bool relayblock);
	
	void eraseinvalidticket(Hash& blockhash);
}
#endif
