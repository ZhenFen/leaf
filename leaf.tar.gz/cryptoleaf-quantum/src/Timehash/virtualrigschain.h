#include <CryptoTypes.h>
#include <list>
#include <map>
#include <stdio.h>



class virtualRigsChain{
	struct altchain{
		Hash head;
		std::map<int, Hash>* chain;
	};
	
	std::map<int, Hash> chain;
	std::map<Hash> signatures;
	std::mutex mut;
	
	void insert(Hash& hash);
	bool validate(std::string& rignature);
	
}
