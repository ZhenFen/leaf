//lamport signatures
